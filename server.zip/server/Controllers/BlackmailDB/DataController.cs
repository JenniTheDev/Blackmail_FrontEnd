using System;
using System.Net;
using System.Data;
using System.Linq;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNet.OData;
using Microsoft.AspNet.OData.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.AspNet.OData.Query;



namespace Blackmail.Controllers.BlackmailDb
{
  using Models;
  using Data;
  using Models.BlackmailDb;

  [ODataRoutePrefix("odata/BlackmailDB/Data")]
  [Route("mvc/odata/BlackmailDB/Data")]
  public partial class DataController : ODataController
  {
    private Data.BlackmailDbContext context;

    public DataController(Data.BlackmailDbContext context)
    {
      this.context = context;
    }
    // GET /odata/BlackmailDb/Data
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    [HttpGet]
    public IEnumerable<Models.BlackmailDb.Datum> GetData()
    {
      var items = this.context.Data.AsQueryable<Models.BlackmailDb.Datum>();
      this.OnDataRead(ref items);

      return items;
    }

    partial void OnDataRead(ref IQueryable<Models.BlackmailDb.Datum> items);

    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    [HttpGet("{idData}")]
    public SingleResult<Datum> GetDatum(int key)
    {
        var items = this.context.Data.Where(i=>i.idData == key);
        return SingleResult.Create(items);
    }
    partial void OnDatumDeleted(Models.BlackmailDb.Datum item);
    partial void OnAfterDatumDeleted(Models.BlackmailDb.Datum item);

    [HttpDelete("{idData}")]
    public IActionResult DeleteDatum(int key)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }


            var item = this.context.Data
                .Where(i => i.idData == key)
                .FirstOrDefault();

            if (item == null)
            {
                return BadRequest();
            }

            this.OnDatumDeleted(item);
            this.context.Data.Remove(item);
            this.context.SaveChanges();
            this.OnAfterDatumDeleted(item);

            return new NoContentResult();
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }

    partial void OnDatumUpdated(Models.BlackmailDb.Datum item);
    partial void OnAfterDatumUpdated(Models.BlackmailDb.Datum item);

    [HttpPut("{idData}")]
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    public IActionResult PutDatum(int key, [FromBody]Models.BlackmailDb.Datum newItem)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (newItem == null || (newItem.idData != key))
            {
                return BadRequest();
            }

            this.OnDatumUpdated(newItem);
            this.context.Data.Update(newItem);
            this.context.SaveChanges();

            var itemToReturn = this.context.Data.Where(i => i.idData == key);
            this.OnAfterDatumUpdated(newItem);
            return new ObjectResult(SingleResult.Create(itemToReturn));
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }

    [HttpPatch("{idData}")]
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    public IActionResult PatchDatum(int key, [FromBody]Delta<Models.BlackmailDb.Datum> patch)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var item = this.context.Data.Where(i => i.idData == key).FirstOrDefault();

            if (item == null)
            {
                return BadRequest();
            }

            patch.Patch(item);

            this.OnDatumUpdated(item);
            this.context.Data.Update(item);
            this.context.SaveChanges();

            var itemToReturn = this.context.Data.Where(i => i.idData == key);
            return new ObjectResult(SingleResult.Create(itemToReturn));
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }

    partial void OnDatumCreated(Models.BlackmailDb.Datum item);
    partial void OnAfterDatumCreated(Models.BlackmailDb.Datum item);

    [HttpPost]
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    public IActionResult Post([FromBody] Models.BlackmailDb.Datum item)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (item == null)
            {
                return BadRequest();
            }

            this.OnDatumCreated(item);
            this.context.Data.Add(item);
            this.context.SaveChanges();

            return Created($"odata/BlackmailDb/Data/{item.idData}", item);
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }
  }
}
