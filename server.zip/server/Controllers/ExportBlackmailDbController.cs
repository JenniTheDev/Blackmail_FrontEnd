﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Blackmail.Data;

namespace Blackmail
{
    public partial class ExportBlackmailDbController : ExportController
    {
        private readonly BlackmailDbContext context;

        public ExportBlackmailDbController(BlackmailDbContext context)
        {
            this.context = context;
        }
        [HttpGet("/export/BlackmailDb/data/csv")]
        [HttpGet("/export/BlackmailDb/data/csv(fileName='{fileName}')")]
        public FileStreamResult ExportDataToCSV(string fileName = null)
        {
            return ToCSV(ApplyQuery(context.Data, Request.Query), fileName);
        }

        [HttpGet("/export/BlackmailDb/data/excel")]
        [HttpGet("/export/BlackmailDb/data/excel(fileName='{fileName}')")]
        public FileStreamResult ExportDataToExcel(string fileName = null)
        {
            return ToExcel(ApplyQuery(context.Data, Request.Query), fileName);
        }
    }
}
