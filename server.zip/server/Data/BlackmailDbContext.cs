using System.Reflection;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Configuration;

using Blackmail.Models.BlackmailDb;

namespace Blackmail.Data
{
  public partial class BlackmailDbContext : Microsoft.EntityFrameworkCore.DbContext
  {
    public BlackmailDbContext(DbContextOptions<BlackmailDbContext> options):base(options)
    {
    }

    public BlackmailDbContext()
    {
    }

    partial void OnModelBuilding(ModelBuilder builder);

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);



        this.OnModelBuilding(builder);
    }


    public DbSet<Blackmail.Models.BlackmailDb.Datum> Data
    {
      get;
      set;
    }
  }
}
